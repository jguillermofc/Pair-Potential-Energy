#include "GreedySelection.h"
#include "indicator.h"
#include "io.h"
#include "Rand.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <limits.h>
#include <time.h>


/* FUNCTIONS FOR THE USE OF THE IDEAL AND NADIR VECTORS */
void allocate_maxmin(REDUCTOR *red){
	if((red->max = (double *) malloc(red->pop.nobj * sizeof(double))) == NULL){
		printf("Error, not enough memory for max\n");
		exit(-1);
	}

	if((red->min = (double *) malloc(red->pop.nobj * sizeof(double))) == NULL){
		printf("Error, not enough memory for min\n");
		exit(-1);
	}
}

void free_maxmin(REDUCTOR *red){
	free(red->max);
	free(red->min);
}

void update_maxmin(REDUCTOR *reductor){
	int i, j;
	for(i = 0; i < reductor->pop.nobj; i++){
		reductor->max[i] = -DBL_MAX;
		reductor->min[i] = DBL_MIN;
	}

	for(i = 0; i < reductor->pop.size; i++){
		if(reductor->pop.filter[i]){
			for(j = 0; j < reductor->pop.nobj; j++){
				if(reductor->pop.obj[i * reductor->pop.nobj + j] < reductor->min[j])
					reductor->min[j] = reductor->pop.obj[i * reductor->pop.nobj + j];
				if(reductor->pop.obj[i * reductor->pop.nobj + j] > reductor->max[j])
					reductor->max[j] = reductor->pop.obj[i * reductor->pop.nobj + j];
			}
		}
	}
}



void normalize(REDUCTOR *reductor){
	update_maxmin(reductor);
	int i, j;
	for(i = 0; i < reductor->pop.size; i++){
		for(j = 0; j < reductor->pop.nobj; j++){
			reductor->pop.norm[i * reductor->pop.nobj + j] = (reductor->pop.obj[i * reductor->pop.nobj + j] - reductor->min[j]) / (reductor->max[j] - reductor->min[j]);
		}
	}
}
/******************************************************************************************/
/* ALLOCATE AND FREE MEMORY FOR STRUCTURES */

void allocate_Population(Population *pop, char *filenamePOF){
	pop->size = pop->nobj = 0;
	pop->obj = readPopulation(NULL, &pop->size, &pop->nobj, filenamePOF, 0);

	if((pop->norm = (double *) malloc(sizeof(double) * pop->nobj * pop->size)) == NULL) {
        printf("Error, not enough memory for population.\n");
        exit(1);
    } 

	if((pop->filter = (int *) malloc(sizeof(int) * pop->size)) == NULL){
        printf("Error, not enough memory for filter array\n");
        exit(1);
    }
    // Activate all individuals
    int i;
    for(i = 0; i < pop->size; i++)
    	pop->filter[i] = 1;
}

// Free population
void free_Population(Population *pop){
	free(pop->filter);
	free(pop->obj);
	free(pop->norm);
}

/******************************************************************************************/
/* FIND MAX OR MIN VALUE IN AN ARRAY */

int findMax(double *data, int size, int *filter){
	int i, index = 0;
	double max = -DBL_MAX;
	for(i = 0; i < size; i++){
		if(filter[i] && data[i] > max){
			max = data[i];
			index = i;
		}
	}
	return index;
}

int findMin(double *data, int size, int *filter){
	int i, index = 0;
	double min = DBL_MAX;
	for(i = 0; i < size; i++){
		if(filter[i] && data[i] < min){
			min = data[i];
			index = i;
		}
	}
	return index;
}

/******************************************************************************************/
/*  POTENTIAL ENERGY GREEDY SELECTION*/

void POTENTIAL_ENERGY_allocate(POTENTIAL_ENERGY *potential, int n, double s, double A){
	if((potential->contribution = (double *) malloc(n * sizeof(double))) == NULL){
		printf("Error! Not enough memory for array of potential energy contributions\n");
		exit(-1);
	}

	if((potential->memoization = (double *) malloc(n * (n + 1) * sizeof(double))) == NULL){
		printf("Error! Not enough memory for memoization structure of potential energy matrix\n");
		exit(-1);
	}
	potential->s = s;
	potential->A = A;
}

void POTENTIAL_ENERGY_free(POTENTIAL_ENERGY *potential){
	free(potential->contribution);
	free(potential->memoization);
}



void POTENTIAL_ENERGY_greedySelection(REDUCTOR *reductor){
	int aux_size = reductor->pop.size, index, cont = 0, i;
	double totalEnergy;
	char *name;
	name = (char *) malloc(500 * sizeof(char));
	normalize(reductor);

	totalEnergy = POTENTIAL_ENERGY_matrix_computation(reductor->pop.norm,  
		reductor->pop.filter,
		reductor->pop.size,
		reductor->s,
		reductor->A,
		reductor->pop.nobj,
		reductor->potential.memoization,
		reductor->potential.contribution,
		reductor->reductorType); 

	printf("POTENTIAL ENERGY (%s) with s = %f and A = %f\n", reductor->reductorType, reductor->potential.s, reductor->potential.A);
	while(aux_size > reductor->N[cont]){
		/*POTENTIAL_ENERGY_contribution(totalEnergy, 
			reductor->pop.filter, 
			reductor->pop.size, 
			reductor->potential.memoization, 
			reductor->potential.contribution);*/
		index = findMax(reductor->potential.contribution, reductor->pop.size, reductor->pop.filter);
		reductor->pop.filter[index] = 0;
		totalEnergy = POTENTIAL_ENERGY_update(reductor->potential.memoization, reductor->pop.filter, reductor->pop.size, index, reductor->potential.contribution);
		aux_size--;
		if(aux_size == reductor->N[cont]){
			sprintf(name, "%s.%d.s_%.3e_A_%.3e.%s",  reductor->filenamePOF, reductor->N[cont], reductor->potential.s, reductor->potential.A, reductor->reductorType);
			writePopulation(&reductor->pop, reductor->N[cont], name, reductor->reductorType);
		 	if(cont < reductor->numSubsets - 1)
				cont++;
		}
	}
	free(name);
}

/*void s_energy_greedySelection(REDUCTOR *reductor){
	int aux_size = reductor->pop.size, index, cont = 0, i;
	int *filter2, *ptr_filter;
	filter2 = (int *) malloc(reductor->pop.size * sizeof(int));
	srand(time(0)); // Set seed for rand() function
	Rseed = (double) rand() / RAND_MAX;
    randomize(Rseed);
	while(aux_size > reductor->N[cont]){
		printf("Posize = %d\n", aux_size);
		if(aux_size > 2 * reductor->N[cont]){
			memset(filter2, 0, reductor->pop.size * sizeof(int));
			for(i = 0; i < 2 * reductor->N[cont]; i++){
				// If the population has been already deleted, continue looking one that is active
				do{
					index = rnd(0, reductor->pop.size - 1);
				}while(reductor->pop.filter[index] == 0);
				filter2[index] = 1;
			}
			ptr_filter = filter2;
		}else{
			// If N <= 2M, then use the remaining individuals.
			ptr_filter = reductor->pop.filter;
		}
		EMO_Indicator_s_energy_contribution(reductor->pop.obj, 
			ptr_filter, 
			reductor->pop.size, 
			reductor->pop.nobj - 1, 
			reductor->pop.nobj, 
			reductor->sc.memoization, 
			reductor->sc.csenergy);
		index = findMax(reductor->sc.csenergy, reductor->pop.size, reductor->pop.filter);
		reductor->pop.filter[index] = 0;
		aux_size--;
		if(aux_size == reductor->N[cont]){
			writePopulation(&reductor->pop, reductor->N[cont], reductor->filenamePOF, reductor->reductorType);
		 	if(cont < reductor->numSubsets - 1)
				cont++;
		}
	}

	free(filter2);
}*/

/******************************************************************************************/
/* RUN GREEDY SELECTION */

// Execute greedy selection
void runGreedySelection(REDUCTOR *reductor){
	POTENTIAL_ENERGY_allocate(&reductor->potential, reductor->pop.size, reductor->s, reductor->A);
	POTENTIAL_ENERGY_greedySelection(reductor);
	POTENTIAL_ENERGY_free(&reductor->potential);
}



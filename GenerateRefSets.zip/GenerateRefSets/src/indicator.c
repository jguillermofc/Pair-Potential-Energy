

#ifndef _INDICATOR_
#define _INDICATOR_

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <float.h>
#include <math.h>
#include <omp.h>

#include "indicator.h"
#include "sort.h"
#include "vectorops.h"
#include "pairpotential.h"




double POTENTIAL_ENERGY_update(double *matrix, int *filter, int n, int deleted, double *contribution){
  int i;
  double totalPotentialEnergy = 0.0;
  #pragma omp parallel for reduction(+: totalPotentialEnergy)
  for(i = 0; i < n; i++){
    if(filter[i]){
      matrix[i*(n + 1) + n] -= matrix[i*(n + 1) + deleted];
      contribution[i] = matrix[i*(n + 1) + n];     
      totalPotentialEnergy += matrix[i*(n + 1) + n];
    }
  }
  return totalPotentialEnergy;
}


/*void POTENTIAL_ENERGY_contribution(double totalPotentialEnergy, int *filter, int n, double *matrix, double *contribution){
  int j, k;
  #pragma omp parallel for private(j)
  for(k = 0; k < n; k++){
    if(filter[k]){
      double aux = 0.0;
      for(j = 0; j < n; j++){
        if(filter[j] && j != k){
          aux += matrix[j*(n + 1) + n] - matrix[j*(n + 1) + k];
        }
      }   
      contribution[k] = (totalPotentialEnergy - aux)/2.0;
    }
  }
}*/


double POTENTIAL_ENERGY_matrix_computation(double *f,  int *filter, int n, double s, double A, int dim, double *matrix, double *contribution, char *pair_potential_name){
  int i, j;
  double totalPotentialEnergy = 0.0;
  #pragma omp parallel for private(i) reduction(+:totalPotentialEnergy) 
  for(j = 0; j < n; j++){
    if(filter[j]){
      matrix[j*(n + 1) + n] = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          // Call pair-potential function (kernel function)          
          matrix[j*(n + 1) + i] = pair_potential_function(f + j*dim, f + i*dim, dim, s, A, pair_potential_name);   
          matrix[j*(n + 1) + n] += matrix[j*(n + 1) + i];
        }
      }
      contribution[j] =  matrix[j*(n + 1) + n];
      totalPotentialEnergy +=  matrix[j*(n + 1) + n];
    }
  }
  return totalPotentialEnergy;
}




/*double LJ_matrix_computation(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
  int i, j, size = 0;
  double Es = 0.0;
  #pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux, dist;
          //dist = EMO_vdistplus(f + j*dim, f +i*dim, dim);
          dist = EMO_vdist(f + j*dim, f +i*dim, dim);
          if(dist == 0)
            dist = 1e-4;
          double rmin;

          rmin = pow(2, 1.0/6.0) * 4.1 * pow(10, -10);
          aux = 1.77 * 1000 * ( pow(rmin / dist, 12) - 2 * pow(rmin / dist, 6) );

         
          s_energy_c[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      s_energy_c[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}*/

/*double h1_matrix_computation(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
  int i, j, size = 0;
  double Es = 0.0, power;
  #pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux, dist;
          //dist = EMO_vdistplus(f + j*dim, f +i*dim, dim);
          dist = EMO_innerProduct(f + j*dim, f +i*dim, dim);
          dist /= (double) dim;
          power = 1.0 - (double) dim / 2.0;
          
          aux = pow(2*(1 - dist), power);

         
          s_energy_c[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      s_energy_c[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}*/

/*double h2_matrix_computation(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
  int i, j, size = 0;
  double Es = 0.0;
  #pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux, dist;
          //dist = EMO_vdistplus(f + j*dim, f +i*dim, dim);
          dist = EMO_innerProduct(f + j*dim, f +i*dim, dim) / (double) dim;
          
          aux = pow(2*(1 - dist), -s/2.0);

         
          s_energy_c[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      s_energy_c[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}*/


/*double h3_matrix_computation(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
  int i, j, size = 0;
  double Es = 0.0;
  #pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux, dist;
          //dist = EMO_vdistplus(f + j*dim, f +i*dim, dim);
          dist = EMO_innerProduct(f + j*dim, f +i*dim, dim) / (double) dim;
       
          aux = exp(-s*(1 - dist));

         
          s_energy_c[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      s_energy_c[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}*/


/*double h4_matrix_computation(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
  int i, j, size = 0;
  double Es = 0.0;
  #pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux, dist;
          //dist = EMO_vdistplus(f + j*dim, f +i*dim, dim);
          dist = EMO_innerProduct(f + j*dim, f +i*dim, dim) / (double) dim;
          if(dist == 0)
            dist = 1e-4;
          aux = -log(2*(1 - dist));

         
          s_energy_c[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      s_energy_c[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}*/

/*double gravitation_matrix_computation(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
  int i, j, size = 0;
  double Es = 0.0;
  #pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux, dist, m1, m2;
          //dist = EMO_vdistplus(f + j*dim, f +i*dim, dim);
          dist = EMO_vdist(f + j*dim, f +i*dim, dim);
          m1 = EMO_norm(f + j*dim, dim);
          m2 = EMO_norm(f + i*dim, dim);


          if(dist == 0)
            dist = 1e-4;
          aux = 6.674 * pow(10, -11) * m1 * m2 / (dist * dist);

         
          s_energy_c[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      s_energy_c[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}*/


/*double buckingham_matrix_computation(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
  int i, j, size = 0;
  double Es = 0.0;
  #pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux, dist, q1, q2;
          //dist = EMO_vdistplus(f + j*dim, f +i*dim, dim);
          dist = EMO_vdist(f + j*dim, f +i*dim, dim);
         if(dist == 0)
            dist = 1e-4;

          q1 = EMO_norm(f + j*dim, dim);
          q2 = EMO_norm(f + i*dim, dim);


          aux = 1283.907 * exp(-0.32052*dist) - 10.66158 / pow(dist, 6) + 8.9874 * pow(10, 9) * q1 * q2 / (dist * dist);

         
          s_energy_c[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      s_energy_c[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}*/

/*double prop1_matrix_computation(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
  int i, j, size = 0;
  double Es = 0.0;
  #pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux, dist, q1, q2;
          //dist = EMO_vdistplus(f + j*dim, f +i*dim, dim);
          dist = EMO_vdist(f + j*dim, f +i*dim, dim);
         if(dist == 0)
            dist = 1e-4;

          aux = pow(dist, 4) / 4 -  dist*dist;

         
          s_energy_c[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      s_energy_c[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}*/

/*double morse_matrix_computation(double *f,  int *filter, int n, double s, int dim, double *s_energy_c){
  int i, j, size = 0;
  double Es = 0.0;
  #pragma omp parallel for private(i)
  for(j = 0; j < n; j++){
    if(filter[j]){
      double s_aux = 0.0;
      for(i = 0; i < n; i++){
        if(i != j && filter[i]){
          double aux, dist, q1, q2;
          //dist = EMO_vdistplus(f + j*dim, f +i*dim, dim);
          dist = EMO_vdist(f + j*dim, f +i*dim, dim);
          if(dist == 0)
            dist = 1e-4;
          double alpha = 10;
          double r0 = 0.01;
          double alpha0 = 10.0;
          aux = alpha0 * exp(-2 * alpha * (dist - r0)) - 2 * alpha0 * exp(-alpha * (dist - r0));
         
          s_energy_c[j*(n + 1) + i] = aux;     
          s_aux += aux;
        }
      }
      s_energy_c[j*(n + 1) + n] = s_aux;
      Es += s_aux;
      size++;
    }
  }
  return Es;
}*/
#endif


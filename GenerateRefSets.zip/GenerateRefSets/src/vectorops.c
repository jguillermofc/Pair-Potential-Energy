#include "vectorops.h"
#include <math.h>


#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))


double EMO_norm(double *x, int n) {
  double v = 0;
  int i;

  for(i = 0; i < n; i++)
    v += x[i] * x[i];
  
  return sqrt(v);
}

double EMO_vdist(double *x, double *y, int n) {
  double v = 0;
  int i;

  for(i = 0; i < n; i++)
    v += (x[i] - y[i]) * (x[i] - y[i]);
  
  return sqrt(v);
}


double EMO_innerProduct(double *x, double *y, int n) {
  double v = 0;
  int i;

  for(i = 0; i < n; i++)
    v += x[i]*y[i];
  
  return v;
}


double EMO_vdistplus(double *a, double *b, int dim){
  double sum = 0.0;
  int i;
  for(i = 0; i < dim; i++){
    sum += MAX(a[i] - b[i], 0) * MAX(a[i] - b[i], 0);
  }
  sum = sqrt(sum);
  return sum;
}
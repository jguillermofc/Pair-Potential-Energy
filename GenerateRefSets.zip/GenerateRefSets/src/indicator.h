#ifndef _INDICATOR_H
#define _INDICATOR_H

#include "GreedySelection.h"

// COMMON OPERATIONS
double POTENTIAL_ENERGY_update(double *matrix, int *filter, int n, int deleted, double *contribution);
//void POTENTIAL_ENERGY_contribution(double totalPotentialEnergy, int *filter, int n, double *matrix, double *contribution);
double POTENTIAL_ENERGY_matrix_computation(double *f,  int *filter, int n, double s, double A, int dim, double *matrix, double *contribution, char *pair_potential_name);

#endif

#!/bin/bash

gcc -o reductor *.c -lm -fopenmp
mv reductor ../demo

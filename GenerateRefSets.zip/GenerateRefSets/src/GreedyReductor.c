#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#include "GreedySelection.h"

int numThreads;
char *filenamePOF;
REDUCTOR reductor;



int main(int argc, char *argv[]){
    int i;
    reductor.filenamePOF = argv[2];
    

    if(argc < 6){
        printf("Syntax error, missing parameters\n");
        printf("\n");
        printf("\nSyntax: %s reductorType filenamePOF N_1 [N_2 N_3 ... N_k] numThreads alpha\n", argv[0]);
        printf("\t Reductor type:\n");
        printf("\t\t RSE: Riesz s-energy\n");
        printf("\t\t GAE: Gaussian alpha-energy\n");
        printf("\t\t COU: Coulomb's law\n");
        printf("\t\t PTP:: Poeschl-Teller potential\n");
        printf("\t\t MPT: Modified Poeschl-Teller potential)\n");
        printf("\t\t KRA: Kratzer potential\n");
        printf("\n");
        printf("\n");
        printf("\t filenamePOF is the file to be processed.\n");
        printf("\t N_i are the cardinalities of the desired subsets. They must be sorted in descending order.\n");
        printf("\t numThreads is the number of threads to run\n");
        printf("\t alpha > 0\n");
    
        exit(-1);
    }

    // Assign inputs
    reductor.reductorType = argv[1];
    numThreads = atoi(argv[argc - 2]);
    reductor.N = (int *) malloc((argc - 5) * sizeof(int));
    reductor.numSubsets = argc - 5;
    reductor.s = atof(argv[argc - 1]); 
    reductor.A = 1.0;
    
    
    // Read population from input file (allocation is included)
    allocate_Population(&reductor.pop, reductor.filenamePOF);
    allocate_maxmin(&reductor);
    // Assign subset sizes
    for(i = 0; i < argc - 5; i++){
        reductor.N[i] = atoi(argv[i + 3]);
        if(reductor.N[i] >= reductor.pop.size){
            printf("Subset cardinality %d is greater or igual than the population size %d\n", reductor.N[i], reductor.pop.size);
            exit(-1);
        }
    }

    // Execute greedy selection
    omp_set_num_threads(numThreads);
    runGreedySelection(&reductor);
    // Free population
    free_Population(&reductor.pop);
    free_maxmin(&reductor);
    free(reductor.N);
    
    return 0;
}




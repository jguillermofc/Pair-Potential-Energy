#ifndef __GREEDY_SELECTION_H__
#define __GREEDY_SELECTION_H__

// Memoization units
typedef struct EMO_IC{
	double v_best;		/* Best value found */
	int index_best;		/* Index of the best value */
	double v_second;	/* Second best value found */
	int index_second;	/* Indez of the second best value */
}EMO_IC;

typedef struct
{
	double s;						/* Parameter 1: s value (RSE) or alpha value (GAE, PT, MPT, KRA) */
	double A;						/* Paramter 2: Amplitude value employed by PT and KRA */
	double *contribution;				/* Vector of contributions */
	double *memoization;			/* Memoization */
}POTENTIAL_ENERGY;

typedef struct 
{
	double *obj;
	double *norm;			/* Objective vectors of all individuals */
	int *filter;			/* Indicates which individuals are activated and which do not*/
	int nobj;				/* Objective space dimension */
	int size;				/* Number of individuals */
}Population;


typedef struct 
{
	Population pop;
	POTENTIAL_ENERGY potential;	
	double *max;
	double *min;
	char *reductorType;
	char *filenamePOF;
	char *weightsFile;
	int *N;
	int numSubsets;
	double s;
	double A;
}REDUCTOR;



// Execute greedy selection
void runGreedySelection(REDUCTOR *reductor);

/* POTENTIAL ENERGY REDUCTION */
void POTENTIAL_ENERGY_allocate(POTENTIAL_ENERGY *potential, int n, double s, double A);
void POTENTIAL_ENERGY_free(POTENTIAL_ENERGY *potential);

/* POPULATION */
void allocate_Population(Population *pop, char *filenamePOF);
void free_Population(Population *pop);

void allocate_maxmin(REDUCTOR *red);
void free_maxmin(REDUCTOR *red);



#endif
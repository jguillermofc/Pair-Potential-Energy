#ifndef __PAIR_POTENTIAL__
#define __PAIR_POTENTIAL__

double pair_potential_function(double *u, double *v, int dim, double s, double A, char *type);

#endif
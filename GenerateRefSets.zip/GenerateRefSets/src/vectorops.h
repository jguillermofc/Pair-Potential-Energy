#ifndef __VECTOROPS__
#define __VECTOROPS__


double EMO_norm(double *x, int n);
double EMO_vdist(double *x, double *y, int n);
double EMO_innerProduct(double *x, double *y, int n);
double EMO_vdistplus(double *a, double *b, int dim);

#endif
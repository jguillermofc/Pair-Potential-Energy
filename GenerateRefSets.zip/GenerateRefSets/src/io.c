#include "GreedySelection.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>


double *readPopulation(double *data, int *row, int *col, const char *str, int start) {
  double v;
  FILE *fp;
  int i, j;

  if((fp = fopen(str, "r")) == NULL) {
    printf("Error to open file %s\n", str);
    exit(1);
  }

  if(!fscanf(fp, "# %d %d\n", &i, &j)) {
    printf("Error, missing head %s.\n", str); 
    exit(1);
  }

  if(*row != 0 && (start + i) > *row) {
    printf("Error, not enough space %s %d vs %d.\n", str, (start+i), *row);
    exit(1);
  }
 
  if(*row != 0 && *row < i)
    printf("Warning, truncated file %s: %d rows were read, instead of %d.\n", str, *row, i);
 
  if(*col != 0 && *col != j) {
    printf("Error, mismatch dimension %s col (%d vs %d).\n", str, *col, j);
    exit(1);
  }

  if(i == 0 || j == 0) {
    printf("Error, invalid rows or columns in file %s\n", str);
    exit(1);
  }

  *row = i;
  *col = j;

  if(data == NULL) {
    if((data = (double *) malloc(sizeof(double)*(*row)*(*col))) == NULL) {
      printf("Error, not enough memory in EMO_File_read.\n");
      exit(1);
    }

    if(start != 0) {
      printf("EMO_File_read %s: storing at the beginning of the array.\n", str);
      start = 0;
    }
  }

  for(i = 0; i < *row; i++) {
    for(j = 0; j < *col; j++) {
      if(!fscanf(fp, "%lf", &v)) {
        printf("Error to read file %s in row %d, col %d\n", str, i, j);
        exit(1);
      }

      data[(i + start) * (*col) + j] = v;
    }
  }

  fclose(fp);

  return data; 
}


// Write final population
void writePopulation(Population *pop, int N, char *input, char *reductorType){
    int i, j, mirror;
    char output[500];
    sprintf(output, "output/%s", input);
    
    FILE *fout;
    if((fout = fopen(output, "w")) == NULL){
        printf("Error! The file %s could not be written.\n", output);
        exit(-1);
    }

    fprintf(fout, "# %d %d\n", N, pop->nobj);
    for(i = 0; i < pop->size; i++){
        if(pop->filter[i]){
            for(j = 0; j < pop->nobj; j++)
                fprintf(fout, "%f ", pop->obj[i * pop->nobj + j]);
            fprintf(fout, "\n");
        }
    }
    fclose(fout); 
}

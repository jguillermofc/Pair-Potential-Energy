#ifndef __IO_H__
#define __IO_H__
 

double *readPopulation(double *data, int *row, int *col, const char *str, int start);
void writePopulation(Population *pop, int N, char *input, char *reductorType);

#endif
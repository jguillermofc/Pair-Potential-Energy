#include "pairpotential.h"
#include "vectorops.h"
#include <math.h>
#include <string.h>


double RSE(double *u, double *v, int dim, double s, double A){
	double result, dist;
	dist = EMO_vdist(u, v, dim);
    if(dist == 0)
      	dist = 1e-4;
   	result = (s == 0.0)? log(1.0/dist) : pow(dist, -s); 
   	return result;
}

double GAE(double *u, double *v, int dim, double s, double A){
	double result, dist;
  	dist = EMO_vdist(u, v, dim);
   	if(dist == 0)
      	dist = 1e-4;
   	result = exp(-s * dist * dist);
   	return result;
}

double COU(double *u, double *v, int dim, double s, double A){
	double result, dist, q1, q2;
   	dist = EMO_vdist(u, v, dim);
  	q1 = EMO_norm(u, dim);
   	q2 = EMO_norm(v, dim);

  	if(dist == 0)
     	dist = 1e-4;
  	result = 8.9875517873681764 * pow(10, 9) * q1 * q2 / (dist * dist);
  	return result;
}

double PTP(double *u, double *v, int dim, double s, double A){
	double result, dist, q1, q2;
  	dist = EMO_vdist(u, v, dim);
  	if(dist == 0)
      	dist = 1e-4;
  	/* Pöschl-Teller Potential
		We employed V1 = V2 = A. Hence, we have the function PTP(r) = 4Acsc(2sr)csc(2sr),
		where s is the alpha parameter and r = dist(u, v).

  	*/
  	result = A / pow(sin(s * dist), 2) + A / pow(cos(s * dist), 2);
  	return result;
}

double MPT(double *u, double *v, int dim, double s, double A){
	double result, dist, q1, q2;
   	dist = EMO_vdist(u, v, dim);
  	if(dist == 0)
      	dist = 1e-4;       
 	/* Modified Pöschl-Teller Potential
		The original definition is MPT(r) = -D / cosh^2(s * r). However, if D > 0, this implies
		that the function will have a strictly monotonic ascending behavior, which is not compliant
		with the formula of worst contributing solution (change max to min). Hence, we consider 
		MPT(r) = D / cosh^2(s * r), D > 0. 
 	*/
   	result = A / (cosh(s * dist) * cosh(s * dist));  
   	return result;
}

double KRA(double *u, double *v, int dim, double s, double A){
	double result, dist;
	dist = EMO_vdist(u, v, dim);
	if(dist == 0)
		dist = 1e-4;
	
	/* Kratzer Potential
		We fixed V2 = 1.0 (the final sumand of the funtion)
	*/
	result = A * pow((dist - 1.0/s) / dist, 2) + 1.0;
	return result;
}

double pair_potential_function(double *u, double *v, int dim, double s, double A, char *type){
	double pairPotentialValue;
	if(!strcmp(type, "RSE")){
		pairPotentialValue = RSE(u, v, dim, s, A);
	}else if(!strcmp(type, "GAE")){
		pairPotentialValue = GAE(u, v, dim, s, A);
	}else if(!strcmp(type, "COU")){
		pairPotentialValue = COU(u, v, dim, s, A);
	}else if(!strcmp(type, "PTP")){
		pairPotentialValue = PTP(u, v, dim, s, A);
	}else if(!strcmp(type, "MPT")){
		pairPotentialValue = MPT(u, v, dim, s, A);
	}else if(!strcmp(type, "KRA")){
		pairPotentialValue = KRA(u, v, dim, s, A);
	}
	return pairPotentialValue;
}


